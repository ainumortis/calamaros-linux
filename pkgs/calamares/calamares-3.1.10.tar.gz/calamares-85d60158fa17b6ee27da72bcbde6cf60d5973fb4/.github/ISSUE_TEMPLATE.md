#### Submission type

  - [ ] Bug report
  - [ ] Feature Request


#### Info regarding which version of Calamares is used, which Distribution

> …

#### Provide information on how the disks are set up, in detail, with full logs of commands issued 

> …

#### What do you expect to have happen when Calamares installs?

> …

#### Describe the issue you encountered

> …

#### Steps to reproduce the problem

> …

#### Include the installation.log:

> …
